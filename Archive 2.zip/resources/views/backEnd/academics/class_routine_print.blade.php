<!DOCTYPE html>
<html lang="en">

<head>
    <title>{{ __('Class Routine Master') }}</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="{{ asset('public/backEnd/') }}/vendors/css/print/bootstrap.min.css" />
    <script type="text/javascript" src="{{ asset('public/backEnd/') }}/vendors/js/print/jquery.min.js"></script>
    <script type="text/javascript" src="{{ asset('public/backEnd/') }}/vendors/js/print/bootstrap.min.js"></script>
    <style>
        @page {
            size: landscape;
            margin: 10mm;
        }

        body { font-family: 'dejavu sans', sans-serif; color: #000; }
        
        .header-text { color: #000 !important; }

        table.schedule-matrix { width: 100%; border-collapse: collapse; margin-top: 15px; font-size: 10px; }
        table.schedule-matrix th, table.schedule-matrix td {
            border: 1px solid #000; padding: 6px; text-align: center; vertical-align: top;
        }
        
        .row-year th { background-color: #e2e8f0; font-size: 11px; font-weight: bold; }
        .row-section th { background-color: #f1f5f9; font-size: 10px; font-weight: bold; }
        .row-class th { background-color: #f8fafc; font-size: 10px; font-weight: bold; }
        
        .day-col { font-weight: bold; vertical-align: middle !important; width: 80px; background-color: #f8fafc; }

        .routine-block { 
            border: 1px solid #cbd5e1; border-radius: 4px; padding: 4px; margin-bottom: 4px; 
            background-color: #ffffff; page-break-inside: avoid; text-align: center;
        }
        .type-break { background-color: #fff7ed !important; border-color: #fdba74 !important; }
        .type-class { background-color: #f8fafc !important; }
        
        .routine-time { font-size: 9px; font-weight: bold; color: #333; border-bottom: 1px solid #e2e8f0; padding-bottom: 2px; margin-bottom: 2px; }
        .routine-subject { font-size: 10px; font-weight: bold; color: #000; margin: 2px 0; }
        .routine-meta { font-size: 8px; color: #555; }
    </style>
</head>

<body>
    <div class="container-fluid" id="pdf">
        <table cellspacing="0" width="100%">
            <tr>
                <td style="width: 20%;">
                    <img src="{{ url('/') }}/{{ @generalSetting()->logo }}" style="padding-top: 10px; max-width: 150px;" alt="">
                </td>
                <td style="text-align:center; width: 60%;">
                    <h3 style="font-size:22px !important; margin-bottom: 5px; margin-top: 0px;" class="header-text">
                        {{ isset(generalSetting()->school_name) ? generalSetting()->school_name : 'Infix School Management ERP' }}
                    </h3>
                    <span style="font-size:12px !important; margin:0px; display:block;" class="header-text">
                        {{ isset(generalSetting()->address) ? generalSetting()->address : 'Infix School Address' }}
                    </span>
                </td>
                <td style="text-align:right; width: 20%;">
                    <h3 style="font-size:16px !important; margin-bottom: 0; margin-top: 0px;" class="header-text">
                        @lang('academics.class_routine')
                    </h3>
                    
                    @if(isset($filter_teacher_id) && $filter_teacher_id)
                        @php $t_name = \App\SmStaff::find($filter_teacher_id); @endphp
                        <span style="font-size:11px !important; display:block;" class="header-text">
                            Teacher: {{ $t_name ? $t_name->full_name : '' }}
                        </span>
                    @elseif(isset($filter_class_id) && $filter_class_id)
                        @php $c_name = \App\SmClass::find($filter_class_id); @endphp
                        <span style="font-size:11px !important; display:block;" class="header-text">
                            Class: {{ $c_name ? $c_name->class_name : '' }}
                        </span>
                    @else
                        <span style="font-size:11px !important; display:block;" class="header-text">
                            (Master Schedule)
                        </span>
                    @endif
                    
                    @if(isset($academic_year_id) && $academic_year_id == 'all')
                        <span style="font-size:10px !important; display:block; color: #475569;" class="header-text">
                            All Academic Years
                        </span>
                    @elseif(isset($academic_year_id))
                        @php $a_year = \App\SmAcademicYear::find($academic_year_id); @endphp
                        <span style="font-size:10px !important; display:block; color: #475569;" class="header-text">
                            Academic Year: {{ $a_year ? $a_year->year . ' [' . $a_year->title . ']' : '' }}
                        </span>
                    @endif
                </td>
            </tr>
        </table>
        
        <hr style="border-top: 2px solid #000; margin-bottom: 6px; margin-top: 10px;">

        <table class="schedule-matrix">
            <thead>
                <tr class="row-year">
                    <th class="day-col">ACADEMIC YEAR</th>
                    @foreach($year_headers as $year)
                        <th colspan="{{ $year['colspan'] }}">{{ $year['year_title'] }}</th>
                    @endforeach
                </tr>
                <tr class="row-section">
                    <th class="day-col">SECTION</th>
                    @foreach($section_headers as $sec)
                        <th colspan="{{ $sec['colspan'] }}">{{ $sec['section_name'] }}</th>
                    @endforeach
                </tr>
                <tr class="row-class">
                    <th class="day-col">DAYS \ TIMELINE</th>
                    @foreach($flat_columns as $col)
                        <th>{{ $col['class_name'] }}</th>
                    @endforeach
                </tr>
            </thead>
            <tbody>
                @foreach($matrix_rows as $row)
                    <tr>
                        <td class="day-col">{{ $row['day_name'] }}</td>
                        @foreach($row['cells'] as $index => $cell)
                            <td>
                                @if($flat_columns[$index]['is_dummy'])
                                    <span style="color:#999; font-style: italic;">-</span>
                                @else
                                    @forelse($cell['routines'] as $routine)
                                        <div class="routine-block {{ $routine->is_break == 1 ? 'type-break' : 'type-class' }}">
                                            <div class="routine-time">
                                                {{ date('H:i', strtotime($routine->start_time)) }} - {{ date('H:i', strtotime($routine->end_time)) }}
                                            </div>
                                            @if($routine->is_break == 1)
                                                <div class="routine-subject" style="color: #d97706;">BREAK TIME</div>
                                            @else
                                                <div class="routine-subject">{{ @$routine->subject->subject_name }}</div>
                                                <div class="routine-meta">
                                                    {{ @$routine->teacherDetail->full_name }}<br>
                                                    Rm. {{ @$routine->classRoom->room_no }}
                                                </div>
                                            @endif
                                        </div>
                                    @empty
                                    @endforelse
                                @endif
                            </td>
                        @endforeach
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</body>

<script src="{{ asset('public/vendor/spondonit/js/jquery-3.6.0.min.js') }}"></script>
<script src="{{ asset('public/backEnd/js/pdf/html2pdf.bundle.min.js') }}"></script>
<script src="{{ asset('public/backEnd/js/pdf/html2canvas.min.js') }}"></script>
<script>
    function generatePDF() {
        const element = document.getElementById('pdf');
        var opt = {
            margin: 0.5,
            pagebreak: { mode: ['avoid-all', 'css', 'legacy'] },
            filename: 'master-class-routine.pdf',
            image: { type: 'jpeg', quality: 100 },
            html2canvas: { scale: 5 },
            jsPDF: { unit: 'in', format: 'a4', orientation: 'landscape' }
        };
        html2pdf().set(opt).from(element).save();
    }
    
    $(document).ready(function() {
        @if ($print)
            window.print();
            setTimeout(function() { window.close() }, 3000);
        @else
            generatePDF();
        @endif
    })
</script>
</html>